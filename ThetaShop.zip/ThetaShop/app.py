from flask import Flask, render_template, redirect, url_for, request, session

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Assicurati di usare una chiave segreta unica e complessa

# Lista dei prodotti disponibili
products = [
    {'id': 1, 'name': 'T-shirt', 'price': 19.99, 'image': 'tshirt.jpg'},
    {'id': 2, 'name': 'Jeans', 'price': 49.99, 'image': 'jeans.jpg'},
    {'id': 3, 'name': 'Giacca', 'price': 89.99, 'image': 'jacket.jpg'},
    {'id': 4, 'name': 'Felpa', 'price': 29.99, 'image': 'sweater.jpg'},
    {'id': 5, 'name': 'Cappello', 'price': 15.99, 'image': 'hat.jpg'},
    {'id': 6, 'name': 'Stivali', 'price': 79.99, 'image': 'boots.jpg'},
    {'id': 7, 'name': 'Parka', 'price': 119.99, 'image': 'parka.jpg'},
    {'id': 8, 'name': 'Scarpe', 'price': 59.99, 'image': 'shoes.jpg'}
]

# Inizializza il carrello nella sessione
@app.before_request
def before_request():
    if 'cart' not in session:
        session['cart'] = []

@app.route('/')
def index():
    # Debug: Mostra il contenuto del carrello
    print("Carrello:", session.get('cart', []))
    return render_template('index.html', products=products, cart=session['cart'])

@app.route('/add_to_cart/<int:product_id>')
def add_to_cart(product_id):
    product = next((item for item in products if item['id'] == product_id), None)
    if product:
        session['cart'].append(product)
        session.modified = True  # Forza Flask a rilevare la modifica della sessione
        print(f"Prodotto aggiunto: {product['name']}")  # Debug
    else:
        print(f"Prodotto con ID {product_id} non trovato.")  # Debug
    return redirect(url_for('index'))

@app.route('/remove_from_cart/<int:product_id>')
def remove_from_cart(product_id):
    session['cart'] = [item for item in session['cart'] if item['id'] != product_id]
    session.modified = True  # Forza Flask a rilevare la modifica della sessione
    print(f"Prodotto rimosso con ID {product_id}")  # Debug
    return redirect(url_for('view_cart'))

@app.route('/cart')
def view_cart():
    total = sum(item['price'] for item in session['cart'])
    # Debug: Mostra il contenuto del carrello
    print("Carrello visualizzato:", session.get('cart', []))
    return render_template('cart.html', cart=session['cart'], total=total)

@app.route('/checkout', methods=['GET'])
def checkout():
    total = sum(item['price'] for item in session['cart'])
    return render_template('checkout.html', cart=session['cart'], total=total)

@app.route('/complete_order', methods=['POST'])
def complete_order():
    # Gestisci il completamento dell'ordine (esempio: salva l'ordine nel database)
    print("Ordine completato.")  # Debug
    session['cart'] = []  # Pulisce il carrello dopo l'ordine
    return redirect(url_for('index'))  # Torna alla home page dopo aver completato l'ordine

if __name__ == '__main__':
    app.run(debug=True)  # Esegui in modalità di debug per errori dettagliati
